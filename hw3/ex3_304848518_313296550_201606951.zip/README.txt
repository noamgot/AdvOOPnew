BONUS - Configuration:
	The configuration file is aimed to adjust the default values of the game manager parameters.
	Since there is only one adjustable parameter which is the number of threads, we assume the configuration
	file contains only the number of threads value i.e. "-threads <num>".
	The file type is .config
	
	for example: a file named game.config that contains a single line "-threads 20" will result in 20 running threads.

	

Thanks :)